package com.enterprise.emims.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.enterprise.emims.data.model.DashboardSummary
import com.enterprise.emims.data.remote.ApiService
import com.enterprise.emims.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val api: ApiService
) : ViewModel() {

    private val _summary = MutableStateFlow<Resource<DashboardSummary>>(Resource.Loading)
    val summary: StateFlow<Resource<DashboardSummary>> = _summary

    init { load() }

    fun load() {
        viewModelScope.launch {
            _summary.value = Resource.Loading
            _summary.value = try {
                val response = api.getDashboardSummary()
                if (response.isSuccessful && response.body() != null) Resource.Success(response.body()!!)
                else Resource.Error("Failed to load dashboard (${response.code()})")
            } catch (e: Exception) {
                Resource.Error(e.localizedMessage ?: "Network error")
            }
        }
    }
}
