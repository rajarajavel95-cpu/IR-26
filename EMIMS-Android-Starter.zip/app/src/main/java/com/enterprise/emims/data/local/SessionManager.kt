package com.enterprise.emims.data.local

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "emims_session")

/**
 * Persists auth tokens and the current user's role/plant, enforces the SRS's
 * "session timeout" non-functional requirement via [SESSION_TIMEOUT_MS], and is the single
 * source of truth AuthInterceptor and RoleAccess both read from.
 */
@Singleton
class SessionManager @Inject constructor(private val context: Context) {

    private object Keys {
        val ACCESS_TOKEN = stringPreferencesKey("access_token")
        val REFRESH_TOKEN = stringPreferencesKey("refresh_token")
        val USER_ROLE = stringPreferencesKey("user_role")
        val USER_ID = stringPreferencesKey("user_id")
        val PLANT_ID = stringPreferencesKey("plant_id")
        val LAST_ACTIVITY = longPreferencesKey("last_activity")
    }

    companion object {
        const val SESSION_TIMEOUT_MS = 30 * 60 * 1000L // 30 min, matches SRS security settings
    }

    val accessToken: Flow<String?> = context.dataStore.data.map { it[Keys.ACCESS_TOKEN] }
    val userRole: Flow<String?> = context.dataStore.data.map { it[Keys.USER_ROLE] }

    suspend fun saveSession(accessToken: String, refreshToken: String, role: String, userId: String, plantId: String?) {
        context.dataStore.edit {
            it[Keys.ACCESS_TOKEN] = accessToken
            it[Keys.REFRESH_TOKEN] = refreshToken
            it[Keys.USER_ROLE] = role
            it[Keys.USER_ID] = userId
            it[Keys.PLANT_ID] = plantId ?: ""
            it[Keys.LAST_ACTIVITY] = System.currentTimeMillis()
        }
    }

    suspend fun touchActivity() {
        context.dataStore.edit { it[Keys.LAST_ACTIVITY] = System.currentTimeMillis() }
    }

    suspend fun isSessionExpired(): Boolean {
        val last = context.dataStore.data.first()[Keys.LAST_ACTIVITY] ?: 0L
        return System.currentTimeMillis() - last > SESSION_TIMEOUT_MS
    }

    suspend fun clearSession() {
        context.dataStore.edit { it.clear() }
    }

    suspend fun currentAccessToken(): String? = context.dataStore.data.first()[Keys.ACCESS_TOKEN]
}
