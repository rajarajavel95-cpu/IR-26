package com.enterprise.emims.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MaterialDao {
    @Query("""
        SELECT * FROM cached_materials
        WHERE sku LIKE '%' || :query || '%' OR name LIKE '%' || :query || '%'
        ORDER BY name ASC
    """)
    fun search(query: String): Flow<List<MaterialEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(materials: List<MaterialEntity>)

    @Query("DELETE FROM cached_materials")
    suspend fun clearAll()
}

@Dao
interface RequisitionSyncDao {
    @Insert
    suspend fun queueForSync(entity: PendingRequisitionEntity): Long

    @Query("SELECT * FROM pending_requisitions WHERE synced = 0")
    suspend fun getUnsynced(): List<PendingRequisitionEntity>

    @Query("UPDATE pending_requisitions SET synced = 1 WHERE localId = :localId")
    suspend fun markSynced(localId: Int)
}
