package com.enterprise.emims.ui.dashboard

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.enterprise.emims.data.model.DashboardSummary
import com.enterprise.emims.ui.notifications.NotificationBadge
import com.enterprise.emims.ui.notifications.NotificationViewModel
import com.enterprise.emims.util.Resource

private data class StatCard(val label: String, val value: String, val filterKey: String)

@Composable
fun DashboardScreen(
    onOpenSearch: () -> Unit,
    onOpenRequisitions: () -> Unit,
    onOpenExcelImport: () -> Unit,
    onOpenNotifications: () -> Unit,
    onCardClick: (filterKey: String) -> Unit,
    viewModel: DashboardViewModel = hiltViewModel(),
    notificationViewModel: NotificationViewModel = hiltViewModel()
) {
    val state by viewModel.summary.collectAsStateWithLifecycle()
    val notificationState by notificationViewModel.state.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Top bar: IR logo/company name (host activity supplies branding chrome), notifications bell, Excel entry.
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Dashboard", style = MaterialTheme.typography.headlineSmall)
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onOpenExcelImport) {
                    Icon(Icons.Default.UploadFile, contentDescription = "Excel Import/Export")
                }
                Box {
                    IconButton(onClick = onOpenNotifications) {
                        Icon(Icons.Default.Notifications, contentDescription = "Notifications")
                    }
                    Box(modifier = Modifier.align(Alignment.TopEnd).padding(top = 6.dp, end = 6.dp)) {
                        NotificationBadge(count = notificationState.unreadCount)
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        // Smart universal search entry point — SRS: material code/description/plant/rack/location/bin.
        OutlinedTextField(
            value = "",
            onValueChange = { },
            readOnly = true,
            placeholder = { Text("Search materials, rack, plant, bin...") },
            modifier = Modifier.fillMaxWidth().clickable { onOpenSearch() },
            enabled = false
        )
        Spacer(Modifier.height(16.dp))

        when (state) {
            is Resource.Loading -> Box(Modifier.fillMaxWidth().padding(32.dp), Alignment.Center) {
                CircularProgressIndicator()
            }
            is Resource.Error -> Text(
                (state as Resource.Error).message,
                color = MaterialTheme.colorScheme.error
            )
            is Resource.Success -> {
                val summary = (state as Resource.Success<DashboardSummary>).data
                val cards = buildStatCards(summary)
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(cards) { card ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable {
                                if (card.filterKey == "requisitions") onOpenRequisitions()
                                else onCardClick(card.filterKey)
                            }
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Text(card.value, style = MaterialTheme.typography.headlineSmall)
                                Text(card.label, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun buildStatCards(s: DashboardSummary): List<StatCard> = listOf(
    StatCard("Total Materials", s.totalMaterials.toString(), "all_materials"),
    StatCard("Total Quantity", s.totalQuantity.toString(), "all_materials"),
    StatCard("Plants", s.plantCount.toString(), "plants"),
    StatCard("Racks", s.rackCount.toString(), "racks"),
    StatCard("Low Stock", s.lowStockCount.toString(), "low_stock"),
    StatCard("Zero Stock", s.zeroStockCount.toString(), "zero_stock"),
    StatCard("Pending Requests", s.pendingRequisitions.toString(), "requisitions"),
    StatCard("Approved Requests", s.approvedRequisitions.toString(), "requisitions"),
    StatCard("Rejected Requests", s.rejectedRequisitions.toString(), "requisitions")
)
