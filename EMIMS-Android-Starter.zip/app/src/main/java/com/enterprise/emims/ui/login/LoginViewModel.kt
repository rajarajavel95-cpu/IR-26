package com.enterprise.emims.ui.login

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.enterprise.emims.data.repository.AuthRepository
import com.enterprise.emims.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class LoginUiState(
    val companyId: String = "",
    val email: String = "",
    val password: String = "",
    val isLoading: Boolean = false,
    val error: String? = null,
    val loginSuccess: Boolean = false
)

@HiltViewModel
class LoginViewModel @Inject constructor(
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _state = MutableStateFlow(LoginUiState())
    val state: StateFlow<LoginUiState> = _state

    fun onCompanyIdChange(v: String) { _state.value = _state.value.copy(companyId = v, error = null) }
    fun onEmailChange(v: String) { _state.value = _state.value.copy(email = v, error = null) }
    fun onPasswordChange(v: String) { _state.value = _state.value.copy(password = v, error = null) }

    fun login() {
        val s = _state.value
        if (s.companyId.isBlank() || s.email.isBlank() || s.password.isBlank()) {
            _state.value = s.copy(error = "Company ID, email and password are all required.")
            return
        }
        viewModelScope.launch {
            _state.value = s.copy(isLoading = true, error = null)
            when (val result = authRepository.login(s.companyId, s.email, s.password)) {
                is Resource.Success -> _state.value = _state.value.copy(isLoading = false, loginSuccess = true)
                is Resource.Error -> _state.value = _state.value.copy(isLoading = false, error = result.message)
                Resource.Loading -> Unit
            }
        }
    }
}
