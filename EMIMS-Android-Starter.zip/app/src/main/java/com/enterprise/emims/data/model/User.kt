package com.enterprise.emims.data.model

import kotlinx.serialization.Serializable

/**
 * Roles per SRS Chapter 3 permission matrix. Drives RBAC checks throughout the app (see
 * util/RoleAccess.kt) — e.g. only COMPANY_MASTER and SUPER_ADMIN can approve requisitions,
 * only SUPER_ADMIN can create/activate companies. Names must stay in exact sync with the
 * backend's Prisma `Role` enum (emims-backend/prisma/schema.prisma) — login deserializes
 * the role by exact string match.
 */
@Serializable
enum class UserRole {
    SUPER_ADMIN,
    COMPANY_MASTER,
    EXECUTIVE,
    AUDITOR
}

@Serializable
data class User(
    val id: String,
    val name: String,
    val email: String,
    val role: UserRole,
    val plantId: String?,
    val status: String
)

@Serializable
data class LoginRequest(
    val email: String,
    val password: String,
    val companyId: String
)

@Serializable
data class LoginResponse(
    val accessToken: String,
    val refreshToken: String,
    val user: User
)
