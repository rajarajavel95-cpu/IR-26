package com.enterprise.emims.data.repository

import com.enterprise.emims.data.model.AppNotification
import com.enterprise.emims.data.remote.ApiService
import com.enterprise.emims.util.Resource
import javax.inject.Inject

class NotificationRepository @Inject constructor(
    private val api: ApiService
) {
    suspend fun list(unreadOnly: Boolean = false): Resource<List<AppNotification>> = try {
        val response = api.getNotifications(unreadOnly)
        if (response.isSuccessful && response.body() != null) Resource.Success(response.body()!!)
        else Resource.Error("Failed to load notifications (${response.code()})")
    } catch (e: Exception) {
        Resource.Error(e.localizedMessage ?: "Network error")
    }

    suspend fun markRead(id: String): Resource<Unit> = try {
        val response = api.markNotificationRead(id)
        if (response.isSuccessful) Resource.Success(Unit)
        else Resource.Error("Failed to update notification (${response.code()})")
    } catch (e: Exception) {
        Resource.Error(e.localizedMessage ?: "Network error")
    }

    suspend fun unreadCount(): Int = try {
        val response = api.getUnreadNotificationCount()
        if (response.isSuccessful) response.body()?.count ?: 0 else 0
    } catch (e: Exception) {
        0
    }
}
