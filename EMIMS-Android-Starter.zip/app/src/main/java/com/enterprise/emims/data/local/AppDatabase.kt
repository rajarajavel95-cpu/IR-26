package com.enterprise.emims.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [MaterialEntity::class, PendingRequisitionEntity::class],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun materialDao(): MaterialDao
    abstract fun requisitionSyncDao(): RequisitionSyncDao
}
