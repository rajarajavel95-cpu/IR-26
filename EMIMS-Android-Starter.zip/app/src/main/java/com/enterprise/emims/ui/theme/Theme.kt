package com.enterprise.emims.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// IR / EMIMS brand palette. SRS specifies light theme now, dark theme planned later —
// the dark scheme below exists so flipping isSystemInDarkTheme() on costs nothing extra.
private val EmimsBlue = Color(0xFF0B5FFF)
private val EmimsBlueDark = Color(0xFF6EA8FE)

private val LightColors = lightColorScheme(
    primary = EmimsBlue,
    secondary = Color(0xFF00897B)
)

private val DarkColors = darkColorScheme(
    primary = EmimsBlueDark,
    secondary = Color(0xFF4DB6AC)
)

@Composable
fun EmimsTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, content = content)
}
