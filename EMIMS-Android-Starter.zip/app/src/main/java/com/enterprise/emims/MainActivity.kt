package com.enterprise.emims

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.enterprise.emims.data.local.SessionManager
import com.enterprise.emims.data.model.UserRole
import com.enterprise.emims.ui.navigation.EmimsNavGraph
import com.enterprise.emims.ui.theme.EmimsTheme
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    @Inject lateinit var sessionManager: SessionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EmimsTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val roleString by sessionManager.userRole.collectAsStateWithLifecycle(initialValue = null)
                    val role = roleString?.let { runCatching { UserRole.valueOf(it) }.getOrNull() }
                        ?: UserRole.EXECUTIVE
                    EmimsNavGraph(currentUserRole = role)
                }
            }
        }
    }
}
