package com.enterprise.emims.data.repository

import com.enterprise.emims.data.model.*
import com.enterprise.emims.data.remote.ApiService
import com.enterprise.emims.util.Resource
import javax.inject.Inject

class RequisitionRepository @Inject constructor(
    private val api: ApiService
) {
    suspend fun list(status: RequisitionStatus? = null): Resource<List<Requisition>> = try {
        val response = api.getRequisitions(status)
        if (response.isSuccessful && response.body() != null) Resource.Success(response.body()!!)
        else Resource.Error("Failed to load requisitions (${response.code()})")
    } catch (e: Exception) {
        Resource.Error(e.localizedMessage ?: "Network error")
    }

    suspend fun create(items: List<RequisitionItem>): Resource<Requisition> = try {
        val response = api.createRequisition(items)
        if (response.isSuccessful && response.body() != null) Resource.Success(response.body()!!)
        else Resource.Error("Failed to create requisition (${response.code()})")
    } catch (e: Exception) {
        Resource.Error(e.localizedMessage ?: "Network error")
    }

    /**
     * SRS: "Master/Approver reject செய்யும் போது காரணம் கட்டாயம் பதிவாக வேண்டும்" —
     * a rejection MUST carry a reason. Enforced here so no call site can bypass it.
     */
    suspend fun decide(id: String, approve: Boolean, reason: String? = null): Resource<Requisition> {
        if (!approve && reason.isNullOrBlank()) {
            return Resource.Error("A reason is required when rejecting a requisition.")
        }
        return try {
            val response = api.decideRequisition(id, RequisitionDecision(approve, reason))
            if (response.isSuccessful && response.body() != null) Resource.Success(response.body()!!)
            else Resource.Error("Failed to update requisition (${response.code()})")
        } catch (e: Exception) {
            Resource.Error(e.localizedMessage ?: "Network error")
        }
    }
}
