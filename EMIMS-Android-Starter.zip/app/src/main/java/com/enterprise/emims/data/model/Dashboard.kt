package com.enterprise.emims.data.model

import kotlinx.serialization.Serializable

/** Matches SRS 4.2 Dashboard widgets: low-stock alerts, pending approvals, inward/outward volume. */
@Serializable
data class DashboardSummary(
    val totalMaterials: Int,
    val totalQuantity: Double,
    val plantCount: Int,
    val rackCount: Int,
    val lowStockCount: Int,
    val zeroStockCount: Int,
    val pendingRequisitions: Int,
    val approvedRequisitions: Int,
    val rejectedRequisitions: Int,
    val todayInwardVolume: Double,
    val todayOutwardVolume: Double
)

@Serializable
data class ExcelImportResult(
    val importId: String? = null, // present only when validation passed with zero errors; pass to commit
    val totalRows: Int,
    val successRows: Int,
    val errorRows: List<ExcelRowError>
)

@Serializable
data class ExcelRowError(
    val rowNumber: Int,
    val reason: String
)

/** Matches SRS `audit_logs` table: user, action, timestamp, metadata (old/new value). */
@Serializable
data class AuditLogEntry(
    val id: String,
    val userId: String,
    val userName: String,
    val action: String,
    val timestamp: String,
    val oldValue: String? = null,
    val newValue: String? = null,
    val ipOrDevice: String? = null
)
