package com.enterprise.emims.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Local cache row for offline-first search (FR-02). Populated by a background sync worker;
 * this is intentionally a flattened, denormalized copy of Material — it exists purely so the
 * scanner/search screens keep working with no signal in the warehouse.
 */
@Entity(tableName = "cached_materials")
data class MaterialEntity(
    @PrimaryKey val id: String,
    val sku: String,
    val name: String,
    val category: String,
    val uom: String,
    val minThreshold: Double,
    val totalQuantity: Double,
    val locationsJson: String, // serialized List<MaterialLocation>
    val lastSyncedAt: Long
)

@Entity(tableName = "pending_requisitions")
data class PendingRequisitionEntity(
    @PrimaryKey(autoGenerate = true) val localId: Int = 0,
    val itemsJson: String,
    val createdAt: Long,
    val synced: Boolean = false
)
