package com.enterprise.emims.ui.requisition

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.enterprise.emims.data.model.Requisition
import com.enterprise.emims.data.model.RequisitionStatus
import com.enterprise.emims.data.model.UserRole
import com.enterprise.emims.util.RoleAccess

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RequisitionListScreen(
    currentUserRole: UserRole,
    onBack: () -> Unit,
    viewModel: RequisitionViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    var rejectTargetId by remember { mutableStateOf<String?>(null) }
    var rejectReason by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Requisitions") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            state.actionError?.let {
                Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp))
            }
            when {
                state.isLoading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
                state.error != null -> Text(state.error!!, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp))
                else -> LazyColumn(contentPadding = PaddingValues(16.dp)) {
                    items(state.items) { req ->
                        RequisitionCard(
                            requisition = req,
                            canApprove = RoleAccess.canApproveRequisition(currentUserRole) && req.status == RequisitionStatus.PENDING_SUPERVISOR,
                            onApprove = { viewModel.decide(req.id, approve = true) },
                            onRejectClick = { rejectTargetId = req.id }
                        )
                    }
                }
            }
        }
    }

    // Reject requires a reason — cannot be dismissed without one, matching SRS's mandatory-reason rule.
    if (rejectTargetId != null) {
        AlertDialog(
            onDismissRequest = { rejectTargetId = null; rejectReason = "" },
            title = { Text("Reject Requisition") },
            text = {
                Column {
                    Text("A reason is required to reject this request.")
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = rejectReason,
                        onValueChange = { rejectReason = it },
                        placeholder = { Text("Reason for rejection") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = rejectReason.isNotBlank(),
                    onClick = {
                        viewModel.decide(rejectTargetId!!, approve = false, reason = rejectReason)
                        rejectTargetId = null
                        rejectReason = ""
                    }
                ) { Text("Reject") }
            },
            dismissButton = {
                TextButton(onClick = { rejectTargetId = null; rejectReason = "" }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun RequisitionCard(
    requisition: Requisition,
    canApprove: Boolean,
    onApprove: () -> Unit,
    onRejectClick: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Column(Modifier.padding(12.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("Req #${requisition.id}", style = MaterialTheme.typography.titleMedium)
                AssistChip(onClick = {}, label = { Text(requisition.status.name) })
            }
            Text("Requested by: ${requisition.requesterName}", style = MaterialTheme.typography.bodySmall)
            requisition.items.forEach {
                Text("• ${it.sku} — ${it.requestedQty} ${it.uom}", style = MaterialTheme.typography.bodySmall)
            }
            requisition.rejectionReason?.let {
                Text("Rejection reason: $it", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            if (canApprove) {
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onApprove) { Text("Approve") }
                    OutlinedButton(onClick = onRejectClick) { Text("Reject") }
                }
            }
        }
    }
}
