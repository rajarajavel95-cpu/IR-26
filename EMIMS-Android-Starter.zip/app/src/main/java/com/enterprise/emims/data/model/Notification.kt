package com.enterprise.emims.data.model

import kotlinx.serialization.Serializable

/** Matches SRS Chapter 12: new request, approved/rejected, low-stock alerts — real-time in-app. */
@Serializable
enum class NotificationType {
    NEW_REQUEST,
    REQUEST_APPROVED,
    REQUEST_REJECTED,
    LOW_STOCK_ALERT
}

@Serializable
data class AppNotification(
    val id: String,
    val type: NotificationType,
    val title: String,
    val message: String,
    val createdAt: String,
    val isRead: Boolean = false,
    val referenceId: String? = null // e.g. requisitionId or materialId this notification is about
)

@Serializable
data class UnreadCountResponse(val count: Int)
