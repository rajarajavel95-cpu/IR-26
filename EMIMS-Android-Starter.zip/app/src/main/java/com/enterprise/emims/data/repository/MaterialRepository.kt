package com.enterprise.emims.data.repository

import com.enterprise.emims.data.local.MaterialDao
import com.enterprise.emims.data.local.MaterialEntity
import com.enterprise.emims.data.model.Material
import com.enterprise.emims.data.model.MaterialLocation
import com.enterprise.emims.data.remote.ApiService
import com.enterprise.emims.util.Resource
import kotlinx.coroutines.flow.first
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import javax.inject.Inject

/**
 * Offline-first per FR-02: search always reads from the local Room cache. A successful
 * network search refreshes the cache in the background; if the device is offline, the
 * cache is what the user sees. Field/warehouse Wi-Fi is not reliable — never block the
 * search screen on a live network call.
 */
class MaterialRepository @Inject constructor(
    private val api: ApiService,
    private val dao: MaterialDao,
    private val json: Json
) {
    suspend fun search(query: String, plantId: String? = null): Resource<List<Material>> {
        return try {
            val response = api.searchMaterials(query = query, plantId = plantId)
            if (response.isSuccessful && response.body() != null) {
                val materials = response.body()!!.results
                dao.upsertAll(materials.map { it.toEntity(json) })
                Resource.Success(materials)
            } else {
                Resource.Success(cachedSearch(query))
            }
        } catch (e: Exception) {
            // No connectivity in the warehouse — fall back to local cache silently.
            Resource.Success(cachedSearch(query))
        }
    }

    private suspend fun cachedSearch(query: String): List<Material> =
        dao.search(query).first().map { it.toDomain(json) }

    suspend fun getDetail(id: String): Resource<Material> = try {
        val response = api.getMaterialDetail(id)
        if (response.isSuccessful && response.body() != null) Resource.Success(response.body()!!)
        else Resource.Error("Could not load material detail (${response.code()})")
    } catch (e: Exception) {
        Resource.Error(e.localizedMessage ?: "Network error")
    }
}

private fun Material.toEntity(json: Json) = MaterialEntity(
    id = id, sku = sku, name = name, category = category, uom = uom,
    minThreshold = minThreshold, totalQuantity = totalQuantity,
    locationsJson = json.encodeToString(locations),
    lastSyncedAt = System.currentTimeMillis()
)

private fun MaterialEntity.toDomain(json: Json) = Material(
    id = id, sku = sku, name = name, category = category, uom = uom,
    minThreshold = minThreshold, totalQuantity = totalQuantity,
    locations = json.decodeFromString<List<MaterialLocation>>(locationsJson)
)
