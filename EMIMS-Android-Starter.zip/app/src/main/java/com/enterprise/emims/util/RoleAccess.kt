package com.enterprise.emims.util

import com.enterprise.emims.data.model.UserRole

/**
 * Central RBAC matrix, mirrored from SRS Chapter 3. UI screens must check this before
 * showing an action (e.g. Approve button) — the API also enforces it server-side,
 * this is purely for UX (hide actions a role can't perform, don't rely on it for security).
 */
object RoleAccess {

    /** Master User (Company Master) approves/rejects; Super Admin can too (SRS Ch.9). */
    fun canApproveRequisition(role: UserRole): Boolean =
        role == UserRole.COMPANY_MASTER || role == UserRole.SUPER_ADMIN

    /** Only Super Admin creates/activates/deactivates companies (SRS Ch.3). */
    fun canManageCompanies(role: UserRole): Boolean =
        role == UserRole.SUPER_ADMIN

    /** Company Master manages users, plants, racks, bins within their own company (SRS Ch.3). */
    fun canManageUsers(role: UserRole): Boolean =
        role == UserRole.COMPANY_MASTER || role == UserRole.SUPER_ADMIN

    /** Material creation is Company Master only — Executive can only raise a request (SRS Ch.2/4). */
    fun canEditMaterialMaster(role: UserRole): Boolean =
        role == UserRole.COMPANY_MASTER || role == UserRole.SUPER_ADMIN

    fun canImportExcel(role: UserRole): Boolean =
        role == UserRole.COMPANY_MASTER || role == UserRole.SUPER_ADMIN

    fun canViewAuditLogs(role: UserRole): Boolean =
        role == UserRole.AUDITOR || role == UserRole.COMPANY_MASTER || role == UserRole.SUPER_ADMIN

    /** Executive User: view and request only, no direct edits (SRS Ch.3). */
    fun canOnlyRequest(role: UserRole): Boolean =
        role == UserRole.EXECUTIVE
}
