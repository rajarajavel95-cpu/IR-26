package com.enterprise.emims.ui.notifications

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.enterprise.emims.data.model.AppNotification
import com.enterprise.emims.data.repository.NotificationRepository
import com.enterprise.emims.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class NotificationUiState(
    val items: List<AppNotification> = emptyList(),
    val unreadCount: Int = 0,
    val isLoading: Boolean = false,
    val error: String? = null
)

@HiltViewModel
class NotificationViewModel @Inject constructor(
    private val repository: NotificationRepository
) : ViewModel() {

    private val _state = MutableStateFlow(NotificationUiState())
    val state: StateFlow<NotificationUiState> = _state

    init { load() }

    fun load() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null)
            when (val result = repository.list()) {
                is Resource.Success -> _state.value = _state.value.copy(
                    isLoading = false,
                    items = result.data,
                    unreadCount = result.data.count { !it.isRead }
                )
                is Resource.Error -> _state.value = _state.value.copy(isLoading = false, error = result.message)
                Resource.Loading -> Unit
            }
        }
    }

    fun markRead(id: String) {
        viewModelScope.launch {
            if (repository.markRead(id) is Resource.Success) {
                _state.value = _state.value.copy(
                    items = _state.value.items.map { if (it.id == id) it.copy(isRead = true) else it },
                    unreadCount = (_state.value.unreadCount - 1).coerceAtLeast(0)
                )
            }
        }
    }
}
