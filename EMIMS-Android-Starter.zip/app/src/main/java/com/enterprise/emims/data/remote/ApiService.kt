package com.enterprise.emims.data.remote

import com.enterprise.emims.data.model.*
import retrofit2.Response
import retrofit2.http.*

/**
 * Endpoints as literally specified in SRS 5.2. If a new endpoint is needed,
 * add it here AND to the backend OpenAPI spec at the same time — do not let the two drift.
 */
interface ApiService {

    @POST("auth/login")
    suspend fun login(@Body request: LoginRequest): Response<LoginResponse>

    @POST("auth/logout")
    suspend fun logout(): Response<Unit>

    @GET("inventory/search")
    suspend fun searchMaterials(
        @Query("q") query: String,
        @Query("plantId") plantId: String? = null,
        @Query("category") category: String? = null,
        @Query("lowStockOnly") lowStockOnly: Boolean? = null,
        @Query("page") page: Int = 1,
        @Query("pageSize") pageSize: Int = 50
    ): Response<SearchResponse>

    @GET("inventory/materials/{id}")
    suspend fun getMaterialDetail(@Path("id") id: String): Response<Material>

    @GET("requisitions")
    suspend fun getRequisitions(
        @Query("status") status: RequisitionStatus? = null
    ): Response<List<Requisition>>

    @POST("requisitions")
    suspend fun createRequisition(@Body items: List<RequisitionItem>): Response<Requisition>

    @PUT("requisitions/{id}/approve")
    suspend fun decideRequisition(
        @Path("id") id: String,
        @Body decision: RequisitionDecision
    ): Response<Requisition>

    @Multipart
    @POST("excel/import")
    suspend fun importExcel(
        @Part file: okhttp3.MultipartBody.Part
    ): Response<ExcelImportResult>

    @POST("excel/import/{importId}/commit")
    suspend fun commitExcelImport(@Path("importId") importId: String): Response<Unit>

    @GET("excel/export")
    suspend fun exportExcel(
        @Query("plantId") plantId: String? = null,
        @Query("format") format: String = "xlsx"
    ): Response<okhttp3.ResponseBody>

    @GET("dashboard/summary")
    suspend fun getDashboardSummary(): Response<DashboardSummary>

    @GET("audit-logs")
    suspend fun getAuditLogs(
        @Query("userId") userId: String? = null,
        @Query("fromDate") fromDate: String? = null,
        @Query("toDate") toDate: String? = null
    ): Response<List<AuditLogEntry>>

    @GET("notifications")
    suspend fun getNotifications(
        @Query("unreadOnly") unreadOnly: Boolean? = null
    ): Response<List<AppNotification>>

    @PUT("notifications/{id}/read")
    suspend fun markNotificationRead(@Path("id") id: String): Response<Unit>

    @GET("notifications/unread-count")
    suspend fun getUnreadNotificationCount(): Response<UnreadCountResponse>
}
