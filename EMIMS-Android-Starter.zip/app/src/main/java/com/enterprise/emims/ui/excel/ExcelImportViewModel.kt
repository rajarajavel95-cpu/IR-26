package com.enterprise.emims.ui.excel

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.enterprise.emims.data.model.ExcelImportResult
import com.enterprise.emims.data.repository.ExcelRepository
import com.enterprise.emims.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

data class ExcelImportUiState(
    val selectedFileName: String? = null,
    val isUploading: Boolean = false,
    val isConfirming: Boolean = false,
    val result: ExcelImportResult? = null,
    val confirmed: Boolean = false,
    val error: String? = null
) {
    // SRS: "Error இருந்தால்... சரி செய்யும் வரை upload அனுமதிக்கக்கூடாது" —
    // confirm/commit stays disabled while any row has an error or no importId was issued.
    val canConfirm: Boolean get() = result != null && result.errorRows.isEmpty() && result.importId != null
}

@HiltViewModel
class ExcelImportViewModel @Inject constructor(
    private val repository: ExcelRepository
) : ViewModel() {

    private val _state = MutableStateFlow(ExcelImportUiState())
    val state: StateFlow<ExcelImportUiState> = _state

    fun onFileSelected(file: File) {
        _state.value = ExcelImportUiState(selectedFileName = file.name, isUploading = true)
        viewModelScope.launch {
            when (val result = repository.import(file)) {
                is Resource.Success -> _state.value = _state.value.copy(isUploading = false, result = result.data)
                is Resource.Error -> _state.value = _state.value.copy(isUploading = false, error = result.message)
                Resource.Loading -> Unit
            }
        }
    }

    fun confirm() {
        val importId = _state.value.result?.importId ?: return
        viewModelScope.launch {
            _state.value = _state.value.copy(isConfirming = true, error = null)
            when (val result = repository.commit(importId)) {
                is Resource.Success -> _state.value = _state.value.copy(isConfirming = false, confirmed = true)
                is Resource.Error -> _state.value = _state.value.copy(isConfirming = false, error = result.message)
                Resource.Loading -> Unit
            }
        }
    }

    fun reset() {
        _state.value = ExcelImportUiState()
    }
}
