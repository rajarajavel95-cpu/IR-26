package com.enterprise.emims.data.repository

import com.enterprise.emims.data.local.SessionManager
import com.enterprise.emims.data.model.LoginRequest
import com.enterprise.emims.data.remote.ApiService
import com.enterprise.emims.util.Resource
import javax.inject.Inject

class AuthRepository @Inject constructor(
    private val api: ApiService,
    private val sessionManager: SessionManager
) {
    suspend fun login(companyId: String, email: String, password: String): Resource<Unit> {
        return try {
            val response = api.login(LoginRequest(email, password, companyId))
            if (response.isSuccessful && response.body() != null) {
                val body = response.body()!!
                sessionManager.saveSession(
                    accessToken = body.accessToken,
                    refreshToken = body.refreshToken,
                    role = body.user.role.name,
                    userId = body.user.id,
                    plantId = body.user.plantId
                )
                Resource.Success(Unit)
            } else {
                Resource.Error("Login failed: ${response.code()} ${response.message()}")
            }
        } catch (e: Exception) {
            Resource.Error(e.localizedMessage ?: "Network error during login")
        }
    }

    suspend fun logout() {
        try { api.logout() } catch (_: Exception) { /* best-effort; clear local session regardless */ }
        sessionManager.clearSession()
    }
}
