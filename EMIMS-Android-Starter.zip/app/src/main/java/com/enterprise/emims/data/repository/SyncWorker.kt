package com.enterprise.emims.data.repository

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.enterprise.emims.data.local.RequisitionSyncDao
import com.enterprise.emims.data.model.RequisitionItem
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

/**
 * Satisfies FR-02 "background synchronization": runs periodically (scheduled from
 * MainActivity/Application via WorkManager) and flushes any requisitions that were
 * created while the device was offline in the warehouse.
 */
@HiltWorker
class SyncWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val syncDao: RequisitionSyncDao,
    private val requisitionRepository: RequisitionRepository,
    private val json: Json
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val pending = syncDao.getUnsynced()
        var allSucceeded = true

        for (entry in pending) {
            val items = json.decodeFromString<List<RequisitionItem>>(entry.itemsJson)
            val result = requisitionRepository.create(items)
            if (result is com.enterprise.emims.util.Resource.Success) {
                syncDao.markSynced(entry.localId)
            } else {
                allSucceeded = false
            }
        }
        return if (allSucceeded) Result.success() else Result.retry()
    }
}
