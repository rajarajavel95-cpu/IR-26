package com.enterprise.emims.data.model

import kotlinx.serialization.Serializable

@Serializable
data class MaterialLocation(
    val locationId: String,
    val plantCode: String,
    val zone: String,
    val rackNo: String,
    val binNo: String,
    val quantity: Double,
    val batchNo: String? = null
)

/**
 * Mirrors SRS 5.1 `materials` table plus its joined `inventory_stocks` / `locations`
 * rows, since Smart Search (SRS 4.2) needs a material's full multi-location footprint
 * in a single response.
 */
@Serializable
data class Material(
    val id: String,
    val sku: String,
    val name: String,
    val category: String,
    val uom: String,
    val minThreshold: Double,
    val totalQuantity: Double,
    val locations: List<MaterialLocation> = emptyList()
) {
    val isLowStock: Boolean get() = totalQuantity in 0.0..minThreshold
    val isZeroStock: Boolean get() = totalQuantity <= 0.0
}

@Serializable
data class SearchResponse(
    val results: List<Material>,
    val totalCount: Int
)
