package com.enterprise.emims.ui.search

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.enterprise.emims.data.model.Material

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MaterialSearchScreen(
    onBack: () -> Unit,
    onMaterialClick: (String) -> Unit,
    viewModel: MaterialSearchViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Smart Search") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp).fillMaxSize()) {
            OutlinedTextField(
                value = state.query,
                onValueChange = viewModel::onQueryChange,
                placeholder = { Text("SKU, name, plant, rack, bin...") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))

            when {
                state.isLoading -> Box(Modifier.fillMaxWidth().padding(24.dp), Alignment.Center) {
                    CircularProgressIndicator()
                }
                state.error != null -> Text(state.error!!, color = MaterialTheme.colorScheme.error)
                else -> LazyColumn {
                    items(state.results) { material -> MaterialRow(material) { onMaterialClick(material.id) } }
                }
            }
        }
    }
}

@Composable
private fun MaterialRow(material: Material, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        onClick = onClick
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(material.sku, style = MaterialTheme.typography.titleMedium)
                if (material.isZeroStock) {
                    AssistChip(onClick = {}, label = { Text("Zero Stock") })
                } else if (material.isLowStock) {
                    AssistChip(onClick = {}, label = { Text("Low Stock") })
                }
            }
            Text(material.name, style = MaterialTheme.typography.bodyMedium)
            Text(
                "Qty: ${material.totalQuantity} ${material.uom} across ${material.locations.size} location(s)",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
