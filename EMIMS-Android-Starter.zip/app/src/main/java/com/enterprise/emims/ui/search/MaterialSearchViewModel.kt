package com.enterprise.emims.ui.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.enterprise.emims.data.model.Material
import com.enterprise.emims.data.repository.MaterialRepository
import com.enterprise.emims.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SearchUiState(
    val query: String = "",
    val results: List<Material> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null
)

@OptIn(FlowPreview::class)
@HiltViewModel
class MaterialSearchViewModel @Inject constructor(
    private val repository: MaterialRepository
) : ViewModel() {

    private val _state = MutableStateFlow(SearchUiState())
    val state: StateFlow<SearchUiState> = _state

    private val queryFlow = MutableStateFlow("")

    init {
        // SRS: results must return within 1-2 seconds even at 100k+ records — debounce
        // keeps us from hammering the API on every keystroke.
        viewModelScope.launch {
            queryFlow
                .debounce(300)
                .distinctUntilChanged()
                .collect { q -> runSearch(q) }
        }
    }

    fun onQueryChange(q: String) {
        _state.value = _state.value.copy(query = q)
        queryFlow.value = q
    }

    private fun runSearch(query: String) {
        if (query.isBlank()) {
            _state.value = _state.value.copy(results = emptyList(), isLoading = false)
            return
        }
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null)
            when (val result = repository.search(query)) {
                is Resource.Success -> _state.value = _state.value.copy(isLoading = false, results = result.data)
                is Resource.Error -> _state.value = _state.value.copy(isLoading = false, error = result.message)
                Resource.Loading -> Unit
            }
        }
    }
}
