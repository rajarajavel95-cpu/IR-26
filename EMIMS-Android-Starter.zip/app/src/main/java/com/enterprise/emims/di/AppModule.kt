package com.enterprise.emims.di

import android.content.Context
import androidx.room.Room
import com.enterprise.emims.BuildConfig
import com.enterprise.emims.data.local.AppDatabase
import com.enterprise.emims.data.local.SessionManager
import com.enterprise.emims.data.remote.ApiService
import com.enterprise.emims.data.remote.AuthInterceptor
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideSessionManager(@ApplicationContext context: Context): SessionManager =
        SessionManager(context)

    @Provides
    @Singleton
    fun provideOkHttpClient(authInterceptor: AuthInterceptor): OkHttpClient {
        val logging = HttpLoggingInterceptor().apply {
            // SRS security NFR: never log bodies/headers in release builds (tokens, PII).
            level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BODY else HttpLoggingInterceptor.Level.NONE
        }
        return OkHttpClient.Builder()
            .addInterceptor(authInterceptor)
            .addInterceptor(logging)
            // Enforces TLS 1.3 in transit per SRS 3.3 Non-Functional Requirements.
            .connectionSpecs(listOf(okhttp3.ConnectionSpec.RESTRICTED_TLS))
            .build()
    }

    @Provides
    @Singleton
    fun provideAuthInterceptor(sessionManager: SessionManager): AuthInterceptor =
        AuthInterceptor(sessionManager)

    @Provides
    @Singleton
    fun provideJson(): Json = Json { ignoreUnknownKeys = true; isLenient = true }

    @Provides
    @Singleton
    fun provideRetrofit(client: OkHttpClient, json: Json): Retrofit =
        Retrofit.Builder()
            .baseUrl(BuildConfig.BASE_URL)
            .client(client)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()

    @Provides
    @Singleton
    fun provideApiService(retrofit: Retrofit): ApiService = retrofit.create(ApiService::class.java)

    @Provides
    @Singleton
    fun provideAppDatabase(@ApplicationContext context: Context): AppDatabase =
        Room.databaseBuilder(context, AppDatabase::class.java, "emims.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    fun provideMaterialDao(db: AppDatabase) = db.materialDao()

    @Provides
    fun provideRequisitionSyncDao(db: AppDatabase) = db.requisitionSyncDao()
}

private fun String.toMediaType() = okhttp3.MediaType.get(this)
