package com.enterprise.emims.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.enterprise.emims.data.model.UserRole
import com.enterprise.emims.ui.dashboard.DashboardScreen
import com.enterprise.emims.ui.excel.ExcelImportScreen
import com.enterprise.emims.ui.login.LoginScreen
import com.enterprise.emims.ui.notifications.NotificationsScreen
import com.enterprise.emims.ui.requisition.RequisitionListScreen
import com.enterprise.emims.ui.search.MaterialSearchScreen

object Routes {
    const val LOGIN = "login"
    const val DASHBOARD = "dashboard"
    const val SEARCH = "search"
    const val REQUISITIONS = "requisitions"
    const val EXCEL_IMPORT = "excel_import"
    const val NOTIFICATIONS = "notifications"
    const val MATERIAL_DETAIL = "material_detail/{materialId}"

    fun materialDetail(id: String) = "material_detail/$id"
}

@Composable
fun EmimsNavGraph(
    currentUserRole: UserRole,
    navController: NavHostController = rememberNavController()
) {
    NavHost(navController = navController, startDestination = Routes.LOGIN) {

        composable(Routes.LOGIN) {
            LoginScreen(onLoginSuccess = {
                navController.navigate(Routes.DASHBOARD) {
                    popUpTo(Routes.LOGIN) { inclusive = true }
                }
            })
        }

        composable(Routes.DASHBOARD) {
            DashboardScreen(
                onOpenSearch = { navController.navigate(Routes.SEARCH) },
                onOpenRequisitions = { navController.navigate(Routes.REQUISITIONS) },
                onOpenExcelImport = { navController.navigate(Routes.EXCEL_IMPORT) },
                onOpenNotifications = { navController.navigate(Routes.NOTIFICATIONS) },
                onCardClick = { filterKey -> navController.navigate("${Routes.SEARCH}?filter=$filterKey") }
            )
        }

        composable(Routes.EXCEL_IMPORT) {
            ExcelImportScreen(
                onBack = { navController.popBackStack() },
                onConfirmed = { navController.popBackStack() }
            )
        }

        composable(Routes.NOTIFICATIONS) {
            NotificationsScreen(
                onBack = { navController.popBackStack() },
                onNotificationClick = { notification ->
                    notification.referenceId?.let {
                        navController.navigate(Routes.REQUISITIONS)
                    }
                }
            )
        }

        composable(Routes.SEARCH) {
            MaterialSearchScreen(
                onBack = { navController.popBackStack() },
                onMaterialClick = { id -> navController.navigate(Routes.materialDetail(id)) }
            )
        }

        composable(Routes.REQUISITIONS) {
            RequisitionListScreen(
                currentUserRole = currentUserRole,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
