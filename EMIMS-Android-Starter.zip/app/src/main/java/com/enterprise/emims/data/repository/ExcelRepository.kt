package com.enterprise.emims.data.repository

import com.enterprise.emims.data.model.ExcelImportResult
import com.enterprise.emims.data.remote.ApiService
import com.enterprise.emims.util.Resource
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import javax.inject.Inject

class ExcelRepository @Inject constructor(
    private val api: ApiService
) {
    /**
     * SRS Chapter 8: upload -> validation -> preview screen -> confirm -> DB update, with
     * automatic backup before confirm. This call is the "validation" step; the backend
     * returns row-level errors (row number + reason) without committing anything if any
     * row fails — the UI shows them in the preview and blocks confirm until fixed.
     */
    suspend fun import(file: File): Resource<ExcelImportResult> = try {
        val requestFile = file.asRequestBody("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet".toMediaTypeOrNull())
        val part = MultipartBody.Part.createFormData("file", file.name, requestFile)
        val response = api.importExcel(part)
        if (response.isSuccessful && response.body() != null) Resource.Success(response.body()!!)
        else Resource.Error("Import failed (${response.code()})")
    } catch (e: Exception) {
        Resource.Error(e.localizedMessage ?: "Network error during import")
    }

    /** Confirm step (SRS Ch.8: preview -> confirm -> DB update). Only call once validation returned an importId. */
    suspend fun commit(importId: String): Resource<Unit> = try {
        val response = api.commitExcelImport(importId)
        if (response.isSuccessful) Resource.Success(Unit)
        else Resource.Error("Confirm failed (${response.code()})")
    } catch (e: Exception) {
        Resource.Error(e.localizedMessage ?: "Network error during confirm")
    }
}
