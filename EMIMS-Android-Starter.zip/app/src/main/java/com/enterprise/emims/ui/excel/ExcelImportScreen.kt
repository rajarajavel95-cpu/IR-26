package com.enterprise.emims.ui.excel

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.enterprise.emims.data.model.ExcelRowError
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExcelImportScreen(
    onBack: () -> Unit,
    onConfirmed: () -> Unit,
    viewModel: ExcelImportViewModel = hiltViewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            // Copy the picked content:// Uri into a real File so Retrofit's MultipartBody can read it.
            val tempFile = File(context.cacheDir, "import_${System.currentTimeMillis()}.xlsx")
            context.contentResolver.openInputStream(it)?.use { input ->
                FileOutputStream(tempFile).use { output -> input.copyTo(output) }
            }
            viewModel.onFileSelected(tempFile)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Excel Import") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back") }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp).fillMaxSize()) {
            Text(
                "Download the blank template, fill it in, then upload here. " +
                    "Every row is validated before anything is saved — fix any errors shown below and re-upload.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(16.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { filePicker.launch("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") }) {
                    Text("Select Excel File")
                }
                if (state.result != null) {
                    OutlinedButton(onClick = viewModel::reset) { Text("Reset") }
                }
            }

            state.selectedFileName?.let {
                Spacer(Modifier.height(8.dp))
                Text("Selected: $it", style = MaterialTheme.typography.bodySmall)
            }

            if (state.isUploading) {
                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Validating...")
                }
            }

            state.error?.let {
                Spacer(Modifier.height(16.dp))
                Text(it, color = MaterialTheme.colorScheme.error)
            }

            state.result?.let { result ->
                Spacer(Modifier.height(16.dp))
                Text(
                    "Preview: ${result.successRows} of ${result.totalRows} rows valid",
                    style = MaterialTheme.typography.titleSmall
                )
                if (result.errorRows.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "${result.errorRows.size} row(s) need fixing before you can confirm:",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                    LazyColumn(modifier = Modifier.weight(1f)) {
                        items(result.errorRows) { rowError -> ErrorRow(rowError) }
                    }
                } else {
                    Spacer(Modifier.height(8.dp))
                    Text("No errors found. Ready to confirm.", color = MaterialTheme.colorScheme.primary)
                }

                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = viewModel::confirm,
                    enabled = state.canConfirm && !state.isConfirming,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (state.isConfirming) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    } else {
                        Text("Confirm & Update Database")
                    }
                }
            }

            if (state.confirmed) {
                LaunchedEffect(Unit) { onConfirmed() }
            }
        }
    }
}

@Composable
private fun ErrorRow(error: ExcelRowError) {
    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Row(Modifier.padding(8.dp)) {
            Text("Row ${error.rowNumber}: ", style = MaterialTheme.typography.bodySmall)
            Text(error.reason, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
        }
    }
}
