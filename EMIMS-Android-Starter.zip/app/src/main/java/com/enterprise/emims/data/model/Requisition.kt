package com.enterprise.emims.data.model

import kotlinx.serialization.Serializable

/**
 * Exact state machine required by SRS 4.2 "Request Approval Workflow":
 * Draft -> Pending Supervisor -> Approved/Rejected -> Dispatched.
 * Do not add or reorder states without updating the backend enum in lockstep.
 */
@Serializable
enum class RequisitionStatus {
    DRAFT,
    PENDING_SUPERVISOR,
    APPROVED,
    REJECTED,
    DISPATCHED
}

@Serializable
data class RequisitionItem(
    val materialId: String,
    val sku: String,
    val requestedQty: Double,
    val uom: String
)

@Serializable
data class Requisition(
    val id: String,
    val requesterId: String,
    val requesterName: String,
    val approverId: String?,
    val status: RequisitionStatus,
    val items: List<RequisitionItem>,
    val createdAt: String,
    val rejectionReason: String? = null
)

/** Sent on PUT /requisitions/{id}/approve — a reject MUST carry a reason (SRS Chapter on Excel/Request workflow). */
@Serializable
data class RequisitionDecision(
    val approve: Boolean,
    val reason: String? = null
)
