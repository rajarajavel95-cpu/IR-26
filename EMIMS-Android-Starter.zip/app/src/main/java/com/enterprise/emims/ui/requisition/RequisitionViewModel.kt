package com.enterprise.emims.ui.requisition

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.enterprise.emims.data.model.Requisition
import com.enterprise.emims.data.repository.RequisitionRepository
import com.enterprise.emims.util.Resource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class RequisitionListUiState(
    val items: List<Requisition> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val actionError: String? = null
)

@HiltViewModel
class RequisitionViewModel @Inject constructor(
    private val repository: RequisitionRepository
) : ViewModel() {

    private val _state = MutableStateFlow(RequisitionListUiState())
    val state: StateFlow<RequisitionListUiState> = _state

    init { load() }

    fun load() {
        viewModelScope.launch {
            _state.value = _state.value.copy(isLoading = true, error = null)
            when (val result = repository.list()) {
                is Resource.Success -> _state.value = _state.value.copy(isLoading = false, items = result.data)
                is Resource.Error -> _state.value = _state.value.copy(isLoading = false, error = result.message)
                Resource.Loading -> Unit
            }
        }
    }

    /** reason is mandatory for rejection — enforced in the repository, surfaced here as actionError. */
    fun decide(id: String, approve: Boolean, reason: String? = null) {
        viewModelScope.launch {
            when (val result = repository.decide(id, approve, reason)) {
                is Resource.Success -> {
                    _state.value = _state.value.copy(
                        actionError = null,
                        items = _state.value.items.map { if (it.id == id) result.data else it }
                    )
                }
                is Resource.Error -> _state.value = _state.value.copy(actionError = result.message)
                Resource.Loading -> Unit
            }
        }
    }

    fun clearActionError() { _state.value = _state.value.copy(actionError = null) }
}
