# Keep kotlinx.serialization models intact for reflection-free (de)serialization
-keepattributes *Annotation*, InnerClasses
-keep,includedescriptorclasses class com.enterprise.emims.data.model.**$$serializer { *; }
-keepclassmembers class com.enterprise.emims.data.model.** {
    *** Companion;
}
-keepclasseswithmembers class com.enterprise.emims.data.model.** {
    kotlinx.serialization.KSerializer serializer(...);
}
